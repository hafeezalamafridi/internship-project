<?php
session_start();
include '../includes/db.php';

$user_id = $_SESSION['user_id'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];

$sql = "UPDATE users SET name='$name', email='$email', phone='$phone',gender ='$gender' 
WHERE id='$user_id'";
if ($conn->query($sql) === TRUE) {
    echo true;
} else {
    echo false;
}
$conn->close();
?>