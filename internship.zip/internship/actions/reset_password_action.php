<?php
include '../includes/db.php';

$token = $_POST['token'];
$password = md5($_POST['password']);

$sql = "UPDATE users SET password='$password', reset_token=NULL WHERE reset_token='$token'";
if ($conn->query($sql) === TRUE) {
    echo true;
} else {
    echo false;
}
$conn->close();
?>