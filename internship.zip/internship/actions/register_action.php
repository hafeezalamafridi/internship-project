<?php
include '../includes/db.php';
include '../includes/functions.php';
include '../templates/email_template.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$gender = $_POST['gender'];
$password = md5($_POST['password']);

$sql = "INSERT INTO users (name, email, phone,gender, password) 
VALUES ('$name', '$email', '$phone', '$gender','$password')";
if ($conn->query($sql) === TRUE) {
    $subject = "Welcome to Our Website";
    $message = welcomeEmailTemplate($name);
    sendEmail($email, $subject, $message);
    echo true;
} else {
    echo false;
}
$conn->close();
?>