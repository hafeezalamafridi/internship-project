<?php
session_start();
include '../includes/db.php';

$login = $_POST['login'];
$password = md5($_POST['password']);

$sql = "SELECT * FROM users WHERE (name='$login' OR email='$login') AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $_SESSION['user_id'] = $user['id'];
    echo true;
} else {
    echo false;
}
$conn->close();
?>