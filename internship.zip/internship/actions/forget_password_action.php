<?php
include '../includes/db.php';
include '../includes/functions.php';
include '../templates/email_template.php';

$email = $_POST['email'];
$token = generateToken();

$sql = "UPDATE users SET reset_token='$token' WHERE email='$email'";
if ($conn->query($sql) === TRUE) {
    $link = "http://localhost/internship/reset_password.php?token=$token";
    $subject = "Password Reset";
    $message = passwordResetTemplate($link);
    sendEmail($email, $subject, $message);
    echo true;
} else {
    echo false;
}
$conn->close();
?>