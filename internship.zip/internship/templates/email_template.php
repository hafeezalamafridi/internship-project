
<?php
function welcomeEmailTemplate($name) {
    return "
        <html>
        <body>
            <h1>Welcome, $name!</h1>
            <p>Thank you for registering.</p>
        </body>
        </html>
    ";
}

function passwordResetTemplate($link) {
    return "
        <html>
        <body>
            <h1>Password Reset</h1>
            <p>Click the following link to reset your password: <a href='$link'>$link</a></p>
        </body>
        </html>
    ";
}
?>