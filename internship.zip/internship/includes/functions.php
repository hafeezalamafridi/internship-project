<?php
include 'db.php';

function sendEmail($to, $subject, $message) {
    $headers = 'From: noreply@yourdomain.com' . "\r\n" .
               'Reply-To: noreply@yourdomain.com' . "\r\n" .
               'X-Mailer: PHP/' . phpversion();
    mail($to, $subject, $message, $headers);
}

function generateToken() {
    return bin2hex(random_bytes(50));
}
?>